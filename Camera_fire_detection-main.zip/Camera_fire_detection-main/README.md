# fire-detection
install opencv-python

install numpy

Video file:
https://youtu.be/T18xaSZFMpk
